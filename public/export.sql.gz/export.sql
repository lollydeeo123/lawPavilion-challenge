-- Created at 28.2.2020 10:37 using David Grudl MySQL Dump Utility
-- Host: localhost:8000
-- MySQL Server: 5.5.5-10.4.11-MariaDB
-- Database: 

SET NAMES utf8;
SET SQL_MODE='NO_AUTO_VALUE_ON_ZERO';
SET FOREIGN_KEY_CHECKS=0;
SET UNIQUE_CHECKS=0;
SET AUTOCOMMIT=0;
COMMIT;
-- THE END
